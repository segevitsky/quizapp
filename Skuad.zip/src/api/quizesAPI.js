import skuad from './skuad';

export const getAllQuizes = skuad.get("/api/quiz/all");